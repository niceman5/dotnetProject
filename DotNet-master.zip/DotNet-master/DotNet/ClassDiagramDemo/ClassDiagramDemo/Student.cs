﻿namespace ClassDiagramDemo
{
    public class Student
    {
        public int Year
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public void OrderTranscript(bool official)
        {
            throw new System.NotImplementedException();
        }
    }
}
