﻿using System;

class CaseSensitive
{
    static void Main()
    {
        Console.WriteLine("C#은 대소문자 구분 언어");
    }
}
//using system;

//class casesensitive
//{
//    static void main()
//    {
//        console.writeline("C#은 대소문자 구분 언어");
//    }
//}
