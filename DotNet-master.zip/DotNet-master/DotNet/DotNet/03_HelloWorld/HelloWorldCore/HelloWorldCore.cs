﻿using System;

namespace HelloWorldCore
{
    public class HelloWorldCore
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World Core");
        }
    }    
}
