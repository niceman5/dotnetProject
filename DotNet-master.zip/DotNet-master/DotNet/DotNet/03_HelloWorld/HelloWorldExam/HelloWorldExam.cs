﻿using System;

class HelloWorldExam
{
    static void Main()
    {
        Console.WriteLine("Hello, World");
        Console.WriteLine("Hello, World");
    }
}
