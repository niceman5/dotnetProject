﻿//[1] 네임스페이스 선언부
using System; // 현재 cs 파일에서 System 네임스페이스를 사용

//[2] 클래스 선언부
class FileNew
{
    //[3] Main 메서드: 프로그램의 진입점(Entry Point)
    static void Main()
    {
        //[4] 출력문: 
        Console.WriteLine("안녕하세요.");    // 콘솔 화면에 "안녕하세요." 출력
        Console.WriteLine("반갑습니다.");    // 콘솔 화면에 "반갑습니다." 출력
        Console.WriteLine("또 만나요.");     // 콘솔 화면에 "또 만나요." 출력

        Console.ReadLine(); // 한줄 입력 대기
    }
}
