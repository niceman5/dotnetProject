﻿// 공문
using System;

class EmptyStatement
{
    static void Main()
    {
        ;
        ;
        ;
    }
}
