﻿class WriteLineDemo1
{
    static void Main()
    {
        // 네임스페이스.클래스.메서드();
        System.Console.WriteLine("명령 프롬프트에 출력할 내용");        
    }
}
