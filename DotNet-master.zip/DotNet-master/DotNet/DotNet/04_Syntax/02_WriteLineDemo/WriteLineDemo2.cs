﻿using System;

class WriteLineDemo2
{
    static void Main()
    {
        Console.WriteLine("명령 프롬프트에 출력할 내용");        
    }
}
