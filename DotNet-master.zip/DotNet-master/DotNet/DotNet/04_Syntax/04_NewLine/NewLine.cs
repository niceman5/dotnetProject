﻿using System;

class NewLine
{
    static void Main()
    {
        Console.WriteLine("줄\n바꿈");
    }
}
