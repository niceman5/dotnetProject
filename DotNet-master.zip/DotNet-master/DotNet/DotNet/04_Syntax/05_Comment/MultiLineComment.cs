﻿using System; 

class MultiLineComment
{
    static void Main()
    {
        /*
        Console.WriteLine("현재 구문은 실행되지 않습니다.");
        Console.WriteLine("현재 구문은 실행되지 않습니다.");
        */
    }
}
