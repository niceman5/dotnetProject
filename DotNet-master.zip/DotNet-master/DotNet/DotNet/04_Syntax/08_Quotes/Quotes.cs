﻿using System;

class Quotes
{
    static void Main()
    {
        Console.WriteLine("[1] \" 난 큰 따옴표야.");
        Console.WriteLine("[2] \' 난 작은 따옴표야.");
    }
}
