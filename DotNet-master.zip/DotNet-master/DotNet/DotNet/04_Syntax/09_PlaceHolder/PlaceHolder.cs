﻿// 자리 표시자(개체 틀)
using System;

class PlaceHolder
{
    static void Main()
    {
        Console.WriteLine("{0}", "Hello, C#");
    }
}
