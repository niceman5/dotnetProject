﻿using System;

class PlaceHolderChange
{
    static void Main()
    {
        Console.WriteLine("{1}, {0}", "Hello", "C#");
    }
}
