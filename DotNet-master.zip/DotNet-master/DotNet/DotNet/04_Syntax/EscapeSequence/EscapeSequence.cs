﻿using System;

class EscapeSequence
{
    static void Main()
    {
        Console.WriteLine("안녕 \" 난 큰 따옴표야.");
        Console.WriteLine("안녕 \' 난 작은 따옴표야.");
    }
}
