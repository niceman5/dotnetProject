﻿using System;

class IndentSpaceTab
{
    static void Main()
    {
      Console.WriteLine("2칸");
        Console.WriteLine("4칸");
		Console.WriteLine("탭");
    }
}
