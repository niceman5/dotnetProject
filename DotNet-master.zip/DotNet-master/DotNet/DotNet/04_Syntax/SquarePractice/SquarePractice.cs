﻿using System;

class SquarePractice
{
    static void Main()
    {
        Console.WriteLine("***");
        Console.WriteLine("***");
        Console.WriteLine("***");
    }
}
