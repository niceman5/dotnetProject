﻿using System;

class TermExam
{
    static void Main()
    {
        Console.WriteLine("네임스페이스"); 
        Console.WriteLine("클래스"); 
        Console.WriteLine("메서드"); 
    }
}
