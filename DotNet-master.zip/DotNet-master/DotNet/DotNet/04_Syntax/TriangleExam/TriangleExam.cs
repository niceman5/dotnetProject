﻿using System;

class TriangleExam
{
    static void Main()
    {
        Console.WriteLine("*");
        Console.WriteLine("**");
        System.Console.WriteLine("***");
    }
}
