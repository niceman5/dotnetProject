﻿using System;

class Literal
{
    static void Main()
    {
        Console.WriteLine(1234);    //[1] 1234: 정수 리터럴
        Console.WriteLine(3.14F);   //[2] 3.14: 실수 리터럴
        Console.WriteLine('A');     //[3] A: 문자 리터럴
        Console.WriteLine("HELLO"); //[4] HELLO: 문자열 리터럴
    }
}
