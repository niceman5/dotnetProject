﻿using System;

class VariableExam
{
    static void Main()
    {
        int first;

        first = 10;
        int second = 20, third = 30;

        Console.WriteLine("{0}, {1}, {2}", first, second, third);
    }
}
