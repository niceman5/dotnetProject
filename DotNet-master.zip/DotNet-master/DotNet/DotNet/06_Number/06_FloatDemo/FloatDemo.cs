﻿// float 키워드: 실수형 데이터 형식(32비트 부동 소수점 숫자)
using System; 

class FloatDemo
{
    static void Main()
    {
        float f = 99.99F; // 단정밀도 부동 소수점 변수를 선언하고 값을 할당 
        Console.WriteLine("{0}", f); // 99.99
    }
}
