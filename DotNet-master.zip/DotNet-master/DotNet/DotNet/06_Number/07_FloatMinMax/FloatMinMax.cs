﻿using System;

class FloatMinMax
{
    static void Main()
    {
        float min = float.MinValue; // float의 최솟값
        float max = float.MaxValue; // float의 최댓값

       Console.WriteLine(min); // -3.402823E+38
       Console.WriteLine(max); // +3.402823E+38
    }
}
