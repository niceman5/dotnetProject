﻿using System;

class NullableDemo
{
    static void Main()
    {
        int? x = null; // 널 가능 형식
        Console.WriteLine(x);
    }
}
