﻿using System;

class IntegerOverflow
{
    static void Main()
    {
        //byte b = 256; // byte는 0에서 255까지만 저장할 수 있어 에러가 발생
        //Console.WriteLine(b);
    }
}
