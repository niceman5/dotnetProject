﻿using System;

class StringKeyword
{
    static void Main()
    {
        string name = "박용준";
        Console.WriteLine("안녕하세요. {0}입니다.", name);
    }
}
