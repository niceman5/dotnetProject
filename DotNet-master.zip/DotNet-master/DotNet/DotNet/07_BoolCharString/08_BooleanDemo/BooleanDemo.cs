﻿//[?] 논리 자료형: 참(True) 또는 거짓(False) 값 저장
using System;

class BooleanDemo
{
    static void Main()
    {
        bool bln = true; // 참
        Console.WriteLine(bln); // true => True

        bool isFalse = false; // 거짓
        Console.WriteLine(isFalse); // false => False
    }
}
