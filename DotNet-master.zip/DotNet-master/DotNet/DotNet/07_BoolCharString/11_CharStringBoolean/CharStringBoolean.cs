﻿using System;

class CharStringBoolean
{
    static void Main()
    {
        Char c = 'A'; // char
        String s = "안녕하세요."; // string
        Boolean b = true; // bool 

        Console.WriteLine("{0}\n{1}\n{2}", c, s, b);
    }
}
