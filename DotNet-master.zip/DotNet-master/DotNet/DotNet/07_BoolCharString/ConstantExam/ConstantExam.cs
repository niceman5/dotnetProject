﻿using System;

class ConstantExam
{
    static void Main()
    {
        const char c = '가';
        const string s = "HELLO";
        const float f = 3.14F;
        Console.WriteLine($"{c} {s} {f}");
    }
}
