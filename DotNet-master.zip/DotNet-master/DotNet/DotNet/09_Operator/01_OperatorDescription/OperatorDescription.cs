﻿//[?] 연산자(Operator): 더하기, 빼기와 같은 연산을 진행하는 키워드
using System;

class OperatorDescription
{
    static void Main()
    {
        //[?] 식(Expression)
        Console.WriteLine(3 + 5); // 8
        Console.WriteLine(3 - 5); // -2

        //[?] 문(Statement) 
        Console.WriteLine(3 * 5); // 15
        Console.WriteLine(3 / 5); // 0
    }
}
