﻿using System;

class CastingOperator
{
    static void Main()
    {
        int number = (int)3.14; // 3.14를 정수(int)로 변환
        Console.WriteLine(number); // 3
    }
}
