﻿//[?] 정수형 변수의 값을 1씩 증가
using System;

class IncrementNumber
{
    static void Main()
    {
        int num = 10;
        num = num + 1; // 1 증가
        Console.WriteLine(num); // 11
    }
}
