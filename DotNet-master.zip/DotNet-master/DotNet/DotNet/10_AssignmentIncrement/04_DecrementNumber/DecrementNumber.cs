﻿//[?] 정수형 변수의 값을 1씩 감소
using System;

class DecrementNumber
{
    static void Main()
    {
        int num = 10;
        num = num - 1; // 1 감소
        Console.WriteLine(num); // 9
    }
}
