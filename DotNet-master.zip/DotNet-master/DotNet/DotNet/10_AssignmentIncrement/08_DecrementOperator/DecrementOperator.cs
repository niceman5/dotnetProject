﻿//[?] 감소 연산자: 정수 자료형 변수의 값을 1 감소
using System;

class DecrementOperator
{
    static void Main()
    {
        int num = -100;
        --num; // 1 감소
        Console.WriteLine(num); // -101
    }
}
