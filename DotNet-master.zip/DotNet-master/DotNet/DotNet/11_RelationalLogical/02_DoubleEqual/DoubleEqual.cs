﻿using System;

class DoubleEqual
{
    static void Main()
    {
        Console.WriteLine("AAA" == "aaa"); // False
    }
}
