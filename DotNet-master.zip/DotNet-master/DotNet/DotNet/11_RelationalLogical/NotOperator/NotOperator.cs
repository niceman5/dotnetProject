﻿using System;

class NotOperator
{
    static void Main()
    {
        Console.WriteLine(!(1 == 1)); // False
        Console.WriteLine(!(1 != 1)); // True
    }
}
