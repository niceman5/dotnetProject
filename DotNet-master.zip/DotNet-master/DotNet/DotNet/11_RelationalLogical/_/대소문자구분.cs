﻿using System;

public class 대소문자구분
{
    public static void Main()
    {
        Console.WriteLine("AAA" == "aaa"); // False
    }
}
