﻿using System;

class ShiftPractice
{
    static void Main()
    {
        Console.WriteLine(8 >> 3 << 2); // 4
    }
}
