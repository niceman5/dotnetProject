﻿using System;

class ElseNote
{
    static void Main()
    {
        if (1 != 1)
        {
            //Console.WriteLine("조건식이 참이기에 현재 문장이 실행됩니다.");
        }
        else
        {
            Console.WriteLine("조건식이 거짓이기에 현재 문장이 실행됩니다.");
        }
    }
}
