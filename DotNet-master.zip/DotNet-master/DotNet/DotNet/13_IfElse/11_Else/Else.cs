﻿using System;

class Else
{
    static void Main()
    {
        int score = 59;

        if (score >= 60)
        {
            Console.WriteLine("합격");
        }
        else
        {
            Console.WriteLine("불합격");
        }
    }
}
