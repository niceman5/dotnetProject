﻿using System;

class IfElse
{
    static void Main()
    {
        double pi = 3.14;

        if (pi == 3.14)
        {
            Console.WriteLine("pi는 3.14입니다.");        // 참일 때 실행
        }
        else
        {
            Console.WriteLine("pi는 3.14가 아닙니다.");   // 거짓일 때 실행
        }
    }
}
