﻿using System;

class ElseQuiz
{
    static void Main()
    {
        int number = 7;

        if (number % 2 == 0)
        {
            Console.WriteLine("짝수");
        }
        else
        {
            Console.WriteLine("홀수");
        }
    }
}
