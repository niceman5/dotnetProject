﻿using System;

class ForQuiz
{
    static void Main()
    {
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine("안녕하세요. 1");
        }
        for (int i = 1; i <= 5; i++)
        {
            Console.WriteLine("안녕하세요. 2");
        }
        for (int i = 0; i <= 4; i++)
        {
            Console.WriteLine("안녕하세요. 3");
        }
        for (int i = 1; i < 6; i++)
        {
            Console.WriteLine("안녕하세요. 4");
        }
    }
}
