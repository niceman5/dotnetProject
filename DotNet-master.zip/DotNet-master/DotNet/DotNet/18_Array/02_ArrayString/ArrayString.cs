﻿using System;

class ArrayString
{
    static void Main()
    {
        // 문자열 == 문자의 배열
        string arr = "C#8";
        Console.WriteLine(arr[0]); // C
        Console.WriteLine(arr[1]); // #
        Console.WriteLine(arr[2]); // 8
    }
}
