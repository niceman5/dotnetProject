﻿// FunctionDemo.cs
using System;

class FunctionDemo
{
    //[1] Show 메서드(함수) 선언
    static void Show()
    {
        Console.WriteLine("Hello World");
    }

    // Main 메서드(함수)
    static void Main()
    {
        Show(); //[2] 호출
    }
}
