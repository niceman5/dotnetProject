﻿//[?] System.String 클래스 == string 키워드
using System;

class StringClass
{
    static void Main()
    {
        String s1 = "안녕하세요."; // String 클래스
        string s2 = "반갑습니다."; // string 키워드

        Console.WriteLine($"{s1} {s2}"); 
    }
}
