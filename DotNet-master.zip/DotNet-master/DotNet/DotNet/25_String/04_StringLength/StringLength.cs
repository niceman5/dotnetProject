﻿//[?] 문자열의 길이: String.Length 속성
using System;

class StringLength
{
    static void Main()
    {
        string s1 = "Hello.";
        string s2 = "안녕하세요.";
        Console.WriteLine($"{s1.Length}, {s2.Length}");
    }
}
