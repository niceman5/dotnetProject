﻿namespace Dul
{
    /// <summary>
    /// Dul.dll 파일 제작자: RedPlus
    /// </summary>
    public class Creator
    {
        public static string GetName() => "RedPlus";
    }
}
